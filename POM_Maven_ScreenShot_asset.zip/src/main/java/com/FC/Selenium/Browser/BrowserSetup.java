package com.FC.Selenium.Browser;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.FC.Selenium.CommonFunctions.ElementOperations;
import com.FC.Selenium.Constant.BrowserConstants;
import com.FC.Selenium.Properties.ReadProperties;

public class BrowserSetup {
	protected static WebDriver driver;
    static Properties prop;
	public BrowserSetup() {
		this.prop=ReadProperties.readConfig();
		getDriver();
	}
	
	public static WebDriver getDriver() {
		return driver;		
	}
	
	public static void browserSetUp() 
	{
		//if(BrowserConstants.myBrowser.equalsIgnoreCase("chrome")) 
		if(prop.getProperty("myBrowser").equalsIgnoreCase("chrome")) 
		{
			System.setProperty("webdriver.chrome.driver", BrowserConstants.chromePath);  // Chrome		
			driver = new ChromeDriver();
			System.out.println("Chrome Browser is Opened ");
		}
		 else if(BrowserConstants.myBrowser.equalsIgnoreCase("firefox")) 
		 {
			 System.setProperty("webdriver.gecko.driver", BrowserConstants.firefoxPath);  
				driver = new FirefoxDriver();
				System.out.println("Firefox Browser is Opened ");
		 }
		 else {
			 System.out.println("Unsupported Browser :" + BrowserConstants.myBrowser);
		 }	
	}
	
	
	public static void openApplication(String URL) throws IOException 
	{
		driver.get(URL);	
		ElementOperations.captureScreenShot(driver, "/Users/sasi-8475/ZEclipseWorkspace/Pruthvi_Maven/ScrteenShots/Application.png");
	}
	
	public static void implicit() 
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public static void closeBrowser()  
	{
      	implicit();
		//driver.close();  
		driver.quit(); 
	}
	
}
