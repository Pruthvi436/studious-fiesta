package com.FC.Selenium.CommonFunctions;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.FC.Selenium.Browser.BrowserSetup;
import com.FC.Selenium.Properties.ReadProperties;

public class ElementOperations {
	static WebDriver driver;
	  static Properties prop;
	
/*public  ElementOperations() {
		super();
		this.driver=BrowserSetup.getDriver();
		this.prop=ReadProperties.readConfig();
		PageFactory.initElements(driver, this);
	}*/
public static void sendKeys(WebDriver driver,WebElement ele, String value) {
	ele.clear();
	ele.sendKeys(value);
}
public static void captureScreenShot(WebDriver driver,String pathname) throws IOException {
	
	TakesScreenshot screenshot =  ((TakesScreenshot)driver) ;
	File ScreenShotFile = screenshot.getScreenshotAs(OutputType.FILE);
	File destinationPath = new File(pathname);
	FileUtils.copyFile(ScreenShotFile, destinationPath);
	
}
	
}
