package com.FC.Selenium.CommonFunctions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.FC.Selenium.Browser.BrowserSetup;

import junit.framework.Assert;


public class windowOperations {
	
	public windowOperations() {
		this.driver=BrowserSetup.getDriver();
	}

static WebDriver driver;


	public static void windowMax( ) {
		driver.manage().window().maximize();
	}
	public static void refresh( ) {
		driver.navigate().refresh();
	}
	
	public static void backward( ) {
		driver.navigate().back();
	}
	
	 public static String parentWindow() {
		 String parentWindow = driver.getWindowHandle();
		return parentWindow;	
		}
	
	public static void switchNewWindowWithWhileLoop() throws InterruptedException 
	{	
		String parentWindow = parentWindow();
		System.out.println("Im in NewTab method  ");
		//Thread.sleep(2000);
		String parentWindowTitle = driver.getTitle();
		System.out.println("Page Title of Parent Window is : "+ parentWindowTitle);
		Assert.assertEquals(parentWindowTitle, "The Tag Academy");
		// parentWindow = driver.getWindowHandle();	
		//System.out.println("Session id of Parent Window : "+parentWindow);			
		Set<String> childWindow = driver.getWindowHandles();		
		Iterator<String> itr = childWindow.iterator();	
		
		while(itr.hasNext()) { 
			// hasnest() -- it will read a session id ofrom my iterator
			String child = itr.next();
			System.out.println("Session id of Child Window : "+child);	
			if(!parentWindow.equals(child)) {				
				driver.switchTo().window(child);
				System.out.println("Im in child Window, My Title is :"+driver.getTitle());
				Thread.sleep(2000);							
			}
		}		
	}
	
	public static void switchtoParentWindow() {	
		 String parentWindow = parentWindow();
		driver.switchTo().window(parentWindow);		
		driver.close();
	}
	
	
}
