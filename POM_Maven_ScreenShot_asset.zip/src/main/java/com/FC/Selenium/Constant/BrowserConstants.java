package com.FC.Selenium.Constant;

public class BrowserConstants {

	public static String myBrowser="Chrome";
	public static String chromePath ="/Users/sasi-8475/SeleniumDriversAndJars/chromedriver83/chromedriver";
	public static String firefoxPath ="/Users/sasi-8475/Downloads/geckoriver 3";
	public static String applicationURL="https://elearn.proteansoft.in/practice-forms/";
}
