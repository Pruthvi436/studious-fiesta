package com.FC.Selenium.Constant;

public class LoginPageConstant {

	public static String 
	loginUserName="Administrator",
	loginPassword="#Admin@123";
	
}
