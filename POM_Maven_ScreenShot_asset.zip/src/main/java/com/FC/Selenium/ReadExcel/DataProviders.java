package com.FC.Selenium.ReadExcel;

import org.testng.annotations.DataProvider;


public class DataProviders {

	@DataProvider(name="logintest")
	public static Object[][] loginTest()
	{	
		
	ReadExcelFile readExcel = new ReadExcelFile("/Users/sasi-8475/ZEclipseWorkspace/Pruthvi_Maven/TestDataMaven.xlsx");
		//ReadExcelFile readExcel = new ReadExcelFile();
		//readExcel.getExcelFile("/Users/sasi-8475/ZEclipseWorkspace/Pruthvi_POM/TestDataExcel.xlsx");
	int rows = readExcel.getRowCount(0);
	//int cells = readExcel.
	System.out.println("No.Of active Rows in Excel Shhet : "+ rows);
	Object[][]signin_credentials = new Object[rows][2];
	
	for(int i=0;i<rows;i++)
	{
	System.out.println("Row selected Before Iteration :"+ i);
	signin_credentials[i][0] = readExcel.getData(0, i, 0);
	signin_credentials[i][1] = readExcel.getData(0, i, 1);
	
	System.out.println("Row selected After Iteration :"+ i);
/*	
	for(int j=0:j<cells;j++) {
		{
			signin_credentials[i][j] = readExcel.getData(0, i, j);
			signin_credentials[i][j] = readExcel.getData(0, i, j);
	}*/
	
	
	}
	return signin_credentials;
	}
	
	
	
}
