package com.FC.Selenium.ReadExcel;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

//Excel Sheet extenstion --- 1) .XLS   2) .XLSX

public class ReadExcelFile{
	// 1) .XLS -- In POI , use HSSFWorbook 
	// 2) .XLSX -- In POI, use XSSFWorkbook
	/*
	 * Workbook (Excel File)--  XSSF / HSSFWorkbbok
	 * Sheet  -- XSSFSheet / HSSFSheet 
	 * Row  -- Rows
	 * Columns  -- Cell
	 * 
	 * File(class of java) -- is used to get the File
	 */
//HSSFWorkbook workbook;
static XSSFWorkbook work_book;
//HSSFSheet hSheet;
XSSFSheet sheet;

public ReadExcelFile(String excelfilePath) {
try {
File file = new File(excelfilePath)	;  // it gets the file
FileInputStream stream = new FileInputStream(file);  // it reads the file, fielname, file exztension
work_book = new XSSFWorkbook(stream);  // it will read the complete excel datas
}
catch(Exception e) {
System.out.println(e.getMessage());
}
}

/*public static XSSFWorkbook getExcelFile(String excelfilePath) {

try {
File file = new File(excelfilePath)	;  // it gets the file
FileInputStream stream = new FileInputStream(file);  // it reads the file, fielname, file exztension
work_book = new XSSFWorkbook(stream);  // it will read the complete excel datas
}
catch(Exception e) {
System.out.println(e.getMessage());
}
return work_book;

}*/



public String getData(int sheetnumber, int row, int column)
{	
	sheet = work_book.getSheetAt(sheetnumber);  // it will find and read the sheet number	
	String data =sheet.getRow(row).getCell(column).getStringCellValue();  
	// getRow(row) - will find only row no. | 
	//getCell(column) - find only the column no.
	//getStringCellValue(); -- it will read and get the data inside the res. cell.	
return data;
} 

public int getRowCount(int sheetIndex)
{
	int row =work_book.getSheetAt(sheetIndex).getLastRowNum();  // it will find the last row of the sheet
row = row + 1;
return row;
}










}