package com.FC.Selenium.LoginPage;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.FC.Selenium.Browser.BrowserSetup;
import com.FC.Selenium.CommonFunctions.ElementOperations;
import com.FC.Selenium.Constant.BrowserConstants;
import com.FC.Selenium.Constant.LoginPageConstant;
import com.FC.Selenium.Properties.ReadProperties;

public class LoginPage  extends BrowserSetup {
//	static WebDriver driver;
	  static Properties prop;
	
	 public  LoginPage() {
		super();
		this.driver=BrowserSetup.getDriver();
		this.prop=ReadProperties.readConfig();
		PageFactory.initElements(driver, this);
	}
	

	//driver.findElement(By.id("loginUserName"))
//	@FindBy(locatorNAme="value") static WebElement elementName;
	
	@FindBy(id="loginUserName") static WebElement loginUserName;	
	public  void loginUserName(String userName) throws InterruptedException {
		this.prop=ReadProperties.readConfig();
		Thread.sleep(3000);
		//driver.findElement(By.id("loginUserName")).sendKeys(LoginPageConstant.loginUserName);
		//loginUserName.sendKeys(LoginPageConstant.loginUserName);		
		//ElementOperations.sendKeys(driver,loginUserName, prop.getProperty("loginUserName"));
		//loginUserName.sendKeys(prop.getProperty("loginUserName"));
		loginUserName.clear();
		loginUserName.sendKeys(userName);
		
		
	}
	
	@FindBy(id="loginPassword") static WebElement loginPassword;	
	public  void loginPassword(String password) {
		this.prop=ReadProperties.readConfig();
		//loginPassword.sendKeys(LoginPageConstant.loginPassword);
		loginPassword.clear();
		loginPassword.sendKeys(password);
	}
	
	@FindBy(id="loginButton") static WebElement loginButton;	
	public static void loginButton() {
		
		loginButton.click();
	}
	
	static LoginPage login;
	static BrowserSetup browser;
		
	
	@FindBy(css="button[class='btn btn-success']") static WebElement newWindow;
	public static void clickNewWindowButton() {
		newWindow.click();
	}
	
	public static void logout() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.id("navbar_profile")).click();
		driver.findElement(By.id("logoffbutton")).click();
	}
	
	
	@Test
	public static void loginToApplication() throws InterruptedException, IOException {
		browser = new BrowserSetup();
		BrowserSetup.browserSetUp();
		BrowserSetup.openApplication(BrowserConstants.applicationURL);
		BrowserSetup.implicit();
		login = new LoginPage();
		login.loginUserName("");
		login.loginPassword("");
		login.loginButton();
	}
	
}
