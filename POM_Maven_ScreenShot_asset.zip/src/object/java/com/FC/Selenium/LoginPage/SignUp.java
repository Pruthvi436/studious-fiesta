package com.FC.Selenium.LoginPage;

import com.FC.Selenium.Browser.BrowserSetup;

public class SignUp  extends BrowserSetup{

}
