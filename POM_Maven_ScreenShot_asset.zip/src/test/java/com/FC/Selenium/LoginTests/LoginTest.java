package com.FC.Selenium.LoginTests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.FC.Selenium.Browser.BrowserSetup;
import com.FC.Selenium.CommonFunctions.windowOperations;
import com.FC.Selenium.Constant.BrowserConstants;
import com.FC.Selenium.LoginPage.LoginPage;
import com.FC.Selenium.ReadExcel.DataProviders;
import com.FC.Selenium.ReadExcel.ReadExcelFile;

public class LoginTest {

	public LoginTest() {
		super();	
		this.driver=BrowserSetup.getDriver();
		//PageFactory.initElements(driver, this);
	}	
	static WebDriver driver;
	static LoginPage login;
	static BrowserSetup browser;
	static windowOperations winop;
	@BeforeSuite
	public static void driverConf() {
		browser = new BrowserSetup();
		BrowserSetup.browserSetUp();
		
	}
	
	@BeforeMethod
	public static void waiting() {
		BrowserSetup.implicit();
	}
	
	@BeforeClass
	public static void application() throws IOException {
		BrowserSetup.openApplication(BrowserConstants.applicationURL);
	//	BrowserSetup.implicit();
	}
	
	
	@AfterSuite
	public static void closeBrowser() {
		BrowserSetup.closeBrowser();	
	}
	
	
	@Test(priority=2,dataProvider="logintest",dataProviderClass=DataProviders.class)
	public static void loginToApplication(String userName,String password) throws InterruptedException {
		login = new LoginPage();
		login.loginUserName(userName);
		login.loginPassword(password);
		login.loginButton();
		login.logout();
	}
	
   // @Test(priority=3)
	public static void logoutFromApplication() throws InterruptedException {
		login = new LoginPage();
		login.logout();
	}
	
	@Test(priority=1)
	public static void switchToNewWin() throws InterruptedException {
		login = new LoginPage();
		winop = new windowOperations();
		login.clickNewWindowButton();
		BrowserSetup.implicit();
		windowOperations.switchNewWindowWithWhileLoop();
		
	}
	
	@Test(priority=4)
	public static void switchToMainWin() throws InterruptedException {
		windowOperations.switchtoParentWindow();
	}
	
	
	
	
}
