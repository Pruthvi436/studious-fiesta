package com.FC.Selenium.LoginPage;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.FC.Selenium.Browser.BrowserSetup;
import com.FC.Selenium.CommonFunctions.ElementOperations;
import com.FC.Selenium.Constant.LoginPageConstant;
import com.FC.Selenium.Properties.ReadProperties;

public class LoginPage  {
	static WebDriver driver;
	  static Properties prop;
	public  LoginPage() {
		super();
		this.driver=BrowserSetup.getDriver();
		this.prop=ReadProperties.readConfig();
		PageFactory.initElements(driver, this);
	}
	

	//driver.findElement(By.id("loginUserName"))
//	@FindBy(locatorNAme="value") static WebElement elementName;
	
	@FindBy(id="loginUserName") static WebElement loginUserName;	
	public static void loginUserName() {
		//driver.findElement(By.id("loginUserName")).sendKeys(LoginPageConstant.loginUserName);
		//loginUserName.sendKeys(LoginPageConstant.loginUserName);
		ElementOperations.sendKeys(loginUserName, prop.getProperty("loginUserName"));
		//loginUserName.sendKeys(prop.getProperty("loginUserName"));
	}
	
	@FindBy(id="loginPassword") static WebElement loginPassword;	
	public static void loginPassword() {
		loginPassword.sendKeys(LoginPageConstant.loginPassword);
	}
	
	@FindBy(id="loginButton") static WebElement loginButton;	
	public static void loginButton() {
		loginButton.click();
	}
	
	
}
