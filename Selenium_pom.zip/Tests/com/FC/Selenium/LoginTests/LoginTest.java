package com.FC.Selenium.LoginTests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.FC.Selenium.Browser.BrowserSetup;
import com.FC.Selenium.LoginPage.LoginPage;

public class LoginTest {

	public LoginTest() {
		super();	
		//PageFactory.initElements(driver, this);
	}	
	static LoginPage login;
	static BrowserSetup browser;
	
	@BeforeSuite
	public static void driverConf() {
		browser = new BrowserSetup();
		BrowserSetup.browserSetUp();
		BrowserSetup.openApplication();
		BrowserSetup.implicit();
	}
	
	
	@Test
	public static void loginToApplication() {
		login = new LoginPage();
		login.loginUserName();
		login.loginPassword();
		login.loginButton();
	}
	
	
}
