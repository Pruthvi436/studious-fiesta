package com.FC.Selenium.CommonFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ElementOperations {
static WebDriver driver;

public static void sendKeys(WebElement ele, String value) {
	ele.clear();
	ele.sendKeys(value);
}
	
	
}
