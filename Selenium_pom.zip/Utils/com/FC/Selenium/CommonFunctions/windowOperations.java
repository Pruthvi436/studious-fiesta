package com.FC.Selenium.CommonFunctions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class windowOperations {
static WebDriver driver;
static String parentWindow = driver.getWindowHandle();	

	public static void windowMax() {
		driver.manage().window().maximize();
	}
	public static void refresh() {
		driver.navigate().refresh();
	}
	
	public static void backward() {
		driver.navigate().back();
	}
	
	public static void switchNewWindowWithWhileLoop(WebElement newWinButton) throws InterruptedException 
	{
		System.out.println("NewTab ");
		Thread.sleep(2000);
		WebElement newWindow = newWinButton;
		newWindow.click();
		Thread.sleep(2000);
		System.out.println("Page Title of Parent Window is : "+ driver.getTitle());
		parentWindow = driver.getWindowHandle();	
		System.out.println("Session id of Parent Window : "+parentWindow);	
		
		Set<String> childWindow = driver.getWindowHandles();		
		Iterator<String> itr = childWindow.iterator();	
		
		while(itr.hasNext()) { 
			// hasnest() -- it will read a session id ofrom my iterator
			String child = itr.next();
			System.out.println("Session id of Child Window : "+child);	
			if(!parentWindow.equals(child)) {				
				driver.switchTo().window(child);
				System.out.println("Im in child Window, My Title is :"+driver.getTitle());
				Thread.sleep(2000);							
			}
		}		
	}
	
	public static void switchtoParentWindow() {		
		driver.close();  // child window will close
		driver.switchTo().window(parentWindow);		
	}
	
	
}
