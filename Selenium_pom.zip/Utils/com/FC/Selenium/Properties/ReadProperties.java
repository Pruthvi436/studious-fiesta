package com.FC.Selenium.Properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {

	static Properties prop;
	public static Properties readConfig()   {
		prop = new Properties();
		try 
		   {
		FileInputStream read = new FileInputStream("/Users/sasi-8475/ZEclipseWorkspace/Pruthvi_POM/Utils/com/FC/Selenium/Properties/Configuration.properties");
		System.out.println("My Config Properties is Read.");
		// FileInputStream - it will read the complete property file
		prop.load(read);   // It will load the input values to java class
		System.out.println("My Config Properties is Loaded.");
		   }
		   catch(FileNotFoundException nofile) {			
		   }
		   catch(IOException noIO) {			
		    }
		return prop;		
		}
	
	
}
